import open3d as o3d
import json
import numpy as np
import os

PLY_PATH = os.path.join("processing", "reconstruction_refined.ply")

WEB_VIEWER_DIR = os.path.join(".", "web_viewer")
POINTS_JSON_PATH = os.path.join(WEB_VIEWER_DIR, "points.json")

def main():
    print("Loading point cloud from:", PLY_PATH)
    pcd = o3d.io.read_point_cloud(PLY_PATH)

    points = np.asarray(pcd.points)
    print("Number of points:", points.shape[0])

    points_list = points.tolist()

    print("Saving points to:", POINTS_JSON_PATH)
    os.makedirs(WEB_VIEWER_DIR, exist_ok=True)
    with open(POINTS_JSON_PATH, "w") as f:
        json.dump(points_list, f)

    print("Done. points.json created.")

if __name__ == "__main__":
    main()
