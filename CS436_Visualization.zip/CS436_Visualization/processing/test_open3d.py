import open3d as o3d

print("Open3D installed correctly!")