console.log("Virtual Tour Viewer loaded!");

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x111111);

const camera = new THREE.PerspectiveCamera(
  75,
  window.innerWidth / window.innerHeight,
  0.01,
  1000
);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

window.addEventListener("resize", () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

let pointCloud = null;
let cloudCenter = new THREE.Vector3();
let sceneRadius = 1;
let cameraPoses = [];
let currentIndex = 0;
let imagePlanes = [];

let isAnimating = false;
let animStartTime = 0;
const animDuration = 1000;
let animStartPos = new THREE.Vector3();
let animEndPos = new THREE.Vector3();
let animStartQuat = new THREE.Quaternion();
let animEndQuat = new THREE.Quaternion();

function loadPointCloud() {
  fetch("points.json")
    .then((response) => response.json())
    .then((points) => {
      console.log("Loaded points:", points.length);

      const positions = new Float32Array(points.length * 3);
      for (let i = 0; i < points.length; i++) {
        positions[3 * i + 0] = points[i][0];
        positions[3 * i + 1] = points[i][1];
        positions[3 * i + 2] = points[i][2];
      }

      const geometry = new THREE.BufferGeometry();
      geometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));

      const material = new THREE.PointsMaterial({
        color: 0xffffff,
        size: 0.02,
        sizeAttenuation: true
      });

      pointCloud = new THREE.Points(geometry, material);
      scene.add(pointCloud);

      geometry.computeBoundingSphere();
      sceneRadius = geometry.boundingSphere.radius;
      cloudCenter.copy(geometry.boundingSphere.center);

      console.log("Point cloud center:", cloudCenter, "Radius:", sceneRadius);
      
      camera.position.set(
        cloudCenter.x,
        cloudCenter.y + sceneRadius * 0.5,
        cloudCenter.z + sceneRadius * 2
      );
      camera.lookAt(cloudCenter);
    })
    .catch((err) => console.error("Failed to load points.json:", err));
}

function loadCameraPoses() {
  fetch("camera_poses.json")
    .then((response) => response.json())
    .then((data) => {
      cameraPoses = data.slice().sort((a, b) => a.index - b.index).reverse();
      console.log("Loaded poses:", cameraPoses.length);
      
      createImagePlanes();

      if (cameraPoses.length > 0) {
        setTimeout(() => setCameraToPose(0, true), 500);
      }
    })
    .catch((err) => console.error("Failed to load camera_poses.json:", err));
}

function createImagePlanes() {
  const textureLoader = new THREE.TextureLoader();
  
  cameraPoses.forEach((pose, idx) => {
    const imageIndex = pose.index;
    
    textureLoader.load(
      `images/${imageIndex}.jpg`,
      function(texture) {
        const aspect = texture.image.width / texture.image.height;
        
        const planeHeight = 3.0;
        const planeWidth = planeHeight * aspect;
        
        const geometry = new THREE.PlaneGeometry(planeWidth, planeHeight);
        const material = new THREE.MeshBasicMaterial({
          map: texture,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.95
        });
        
        const imagePlane = new THREE.Mesh(geometry, material);
        
        const camPos = new THREE.Vector3(
          pose.center[0],
          pose.center[1],
          pose.center[2]
        );
        
        const R = pose.R;
        const forward = new THREE.Vector3(-R[2][0], -R[2][1], -R[2][2]).normalize();
        
        const planeDistance = 2.0;
        const planePos = camPos.clone().add(forward.clone().multiplyScalar(planeDistance));
        
        imagePlane.position.copy(planePos);
        imagePlane.lookAt(camPos);
        
        imagePlane.userData = { index: imageIndex };
        imagePlanes.push(imagePlane);
        scene.add(imagePlane);
        
        console.log(`Image ${imageIndex} placed`);
      },
      undefined,
      (err) => console.error(`Failed to load image ${imageIndex}:`, err)
    );
  });
}

function computeCameraOrientation(pose) {
  const R = pose.R;
  
  const mat = new THREE.Matrix4();
  mat.set(
    R[0][0], R[1][0], R[2][0], 0,
    R[0][1], R[1][1], R[2][1], 0,
    R[0][2], R[1][2], R[2][2], 0,
    0, 0, 0, 1
  );
  
  const quat = new THREE.Quaternion();
  quat.setFromRotationMatrix(mat);
  return quat;
}

function setCameraToPose(poseIndex, instant = false) {
  if (cameraPoses.length === 0) return;

  poseIndex = Math.max(0, Math.min(poseIndex, cameraPoses.length - 1));
  const pose = cameraPoses[poseIndex];

  const targetPos = new THREE.Vector3(
    pose.center[0],
    pose.center[1],
    pose.center[2]
  );
  
  const targetQuat = computeCameraOrientation(pose);

  if (instant) {
    camera.position.copy(targetPos);
    camera.quaternion.copy(targetQuat);
    currentIndex = poseIndex;
    updateDisplay();
  } else {
    animStartPos.copy(camera.position);
    animEndPos.copy(targetPos);
    animStartQuat.copy(camera.quaternion);
    animEndQuat.copy(targetQuat);
    animStartTime = performance.now();
    isAnimating = true;
    currentIndex = poseIndex;
    updateDisplay();
  }
}

function goToNextPose() {
  const next = (currentIndex + 1) % cameraPoses.length;
  setCameraToPose(next, false);
}

function goToPrevPose() {
  const prev = (currentIndex - 1 + cameraPoses.length) % cameraPoses.length;
  setCameraToPose(prev, false);
}

function updateDisplay() {
  const el = document.getElementById('poseInfo');
  if (el) el.textContent = `${currentIndex + 1} / ${cameraPoses.length}`;
}

window.addEventListener("keydown", (event) => {
  if (event.key === "ArrowRight" || event.key === " ") {
    event.preventDefault();
    goToNextPose();
  } else if (event.key === "ArrowLeft") {
    goToPrevPose();
  } else if (event.key >= "0" && event.key <= "9") {
    const index = parseInt(event.key);
    if (index < cameraPoses.length) {
      setCameraToPose(index, false);
    }
  }
  
  const speed = 0.3;
  const rotSpeed = 0.03;
  
  const forward = new THREE.Vector3();
  camera.getWorldDirection(forward);
  const right = new THREE.Vector3();
  right.crossVectors(forward, new THREE.Vector3(0, 1, 0)).normalize();
  
  if (event.key === "w" || event.key === "W") camera.position.addScaledVector(forward, speed);
  if (event.key === "s" || event.key === "S") camera.position.addScaledVector(forward, -speed);
  if (event.key === "a" || event.key === "A") camera.position.addScaledVector(right, -speed);
  if (event.key === "d" || event.key === "D") camera.position.addScaledVector(right, speed);
  if (event.key === "q" || event.key === "Q") camera.position.y += speed;
  if (event.key === "e" || event.key === "E") camera.position.y -= speed;
  
  if (event.key === "i" || event.key === "I") camera.rotation.x += rotSpeed;
  if (event.key === "k" || event.key === "K") camera.rotation.x -= rotSpeed;
  if (event.key === "j" || event.key === "J") camera.rotation.y += rotSpeed;
  if (event.key === "l" || event.key === "L") camera.rotation.y -= rotSpeed;
  
  if (event.key === "r" || event.key === "R") {
    camera.position.set(cloudCenter.x, cloudCenter.y + sceneRadius * 0.5, cloudCenter.z + sceneRadius * 2);
    camera.lookAt(cloudCenter);
  }
});

let isDragging = false;
let prevMouse = { x: 0, y: 0 };

renderer.domElement.addEventListener('mousedown', (e) => {
  isDragging = true;
  prevMouse = { x: e.clientX, y: e.clientY };
});

renderer.domElement.addEventListener('mousemove', (e) => {
  if (!isDragging) return;
  
  const dx = e.clientX - prevMouse.x;
  const dy = e.clientY - prevMouse.y;
  
  camera.rotation.y -= dx * 0.003;
  camera.rotation.x -= dy * 0.003;
  camera.rotation.x = Math.max(-Math.PI/2, Math.min(Math.PI/2, camera.rotation.x));
  
  prevMouse = { x: e.clientX, y: e.clientY };
});

renderer.domElement.addEventListener('mouseup', () => isDragging = false);
renderer.domElement.addEventListener('mouseleave', () => isDragging = false);

renderer.domElement.addEventListener('wheel', (e) => {
  e.preventDefault();
  const forward = new THREE.Vector3();
  camera.getWorldDirection(forward);
  camera.position.addScaledVector(forward, -e.deltaY * 0.01);
}, { passive: false });

function animate() {
  requestAnimationFrame(animate);

  if (isAnimating) {
    let t = (performance.now() - animStartTime) / animDuration;
    if (t >= 1) {
      t = 1;
      isAnimating = false;
    }
    
    const eased = t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
    
    camera.position.lerpVectors(animStartPos, animEndPos, eased);
    camera.quaternion.slerpQuaternions(animStartQuat, animEndQuat, eased);
  }

  renderer.render(scene, camera);
}

function createUI() {
  const panel = document.createElement('div');
  panel.style.cssText = `
    position: absolute;
    top: 15px;
    left: 15px;
    color: #ccc;
    font-family: Arial, sans-serif;
    font-size: 12px;
    background: rgba(0, 0, 0, 0.7);
    padding: 10px 14px;
    border-radius: 4px;
  `;
  
  panel.innerHTML = `
    <div style="margin-bottom: 6px;"><b>Controls</b></div>
    <div style="line-height: 1.5;">
      Arrow keys: Navigate<br>
      WASD: Move<br>
      Mouse: Look<br>
      R: Reset
    </div>
    <div style="margin-top: 8px; padding-top: 6px; border-top: 1px solid #444;">
      <span id="poseInfo">1 / 0</span>
    </div>
  `;
  
  document.body.appendChild(panel);
}

loadPointCloud();
loadCameraPoses();
createUI();
animate();